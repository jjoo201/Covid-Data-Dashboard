"""
Handles The other part of your dashboard; displays information
about news articles with headlines that mention the terms
”Covid”, ”COVID-19” or ”coronavirus” as well as news article updates
"""
import time
import datetime

import logging
from configparser import ConfigParser

import sched
import requests

import flask

import covid_data_handler

#Setting up a logging file for this module
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s:%(levelname)s:%(name)a:%(message)s')
file_handler = logging.FileHandler('covid_news_handling.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

#Linking this module to the config file
FILE = 'config.json'
config = ConfigParser()
config.read(FILE)

api_key = (config['api_key']['api_key'])
key_terms = (config['api_key']['key_terms'])

SCHEDULEROBJECT = sched.scheduler(time.time, time.sleep)

def news_API_request(covid_terms = 'Covid, COVID-19, coronavirus') -> dict:

    """
    Accesses the current news data of the covid_terms using the request module and the news API
    Args:
        covid_terms = "Covid, COVID-19, coronavirus" : The default values of the terms in which
        we are returning news articles for.

    Returns:
        articles : All the current articles with the keywords specified within the main_url.
        Each article containing the following; id, name, author, title, description, url, urlToImage
        publishedAt, and content.
    """
    try:
        main_url = 'https://newsapi.org/v2/everything?q=' + key_terms +'&apiKey='+api_key
        news = requests.get(main_url).json()
        articles = news['articles']
    #For the instance someone has incorrect URL parameters the config file incorrectly
    except ValueError:
        logger.exception('Invalid API URL')
        main_url = 'https://newsapi.org/v2/everything?q=' + covid_terms +'&apiKey='+api_key
        news = requests.get(main_url).json()
        articles = news['articles']
    else:
        logger.info('News API Called')

    return articles


def update_news(update_interval: str, update_name: int) -> None:
    """
    Initially it will check to see which checkbox has been ticked on the user interface, a user will
    provide a an update interval and an update name on the user interface which will then be used to
    schedule and name an update to the data structure containing the news articles at the given time
    interval.
    The update is recalling the original news_API_request function so that if there is any new
    articles that are returned that will be displayed, effectively updating the displayed news
    articles. These updates are also added to the list 'news_sched_updates' so that it can be
    displayed onto theuser interface

    Args:
        update_interval : The input from the time field on the user interface, this is the time
        in which the user has specified an update for the news articles to take place
        update_name : The input from the field 'update label' on the user interface, this is
        what will be displayed as the title of the update on the scheduled update widgits.
    """

    news_article_ticked = flask.request.args.get('news')

    if news_article_ticked:
        scheduled_total_seconds: int = time_conversion(update_interval)

        update: dict = {'title':update_name, 'content':'News Article Update Scheduled for ' + update_interval}
        covid_data_handler.data_sched_updates.append(update)

        logger.info(update)
        SCHEDULEROBJECT.enter(scheduled_total_seconds, 2, news_API_request)

def time_conversion(update_interval: str) -> int:

    """
    Converts the current time and a scheduled time provided into seconds finding the difference
    between the two, to know what time to schedule an update for.

    Args:
        update_interval : The input from the time field on the user interface, this is the time
        in which the user has specified an upodate to take place

    Returns:
        scheduled_total_seconds : The difference between the current time and scheduled time
        in seconds
    """
    current_time: int = datetime.datetime.now()
    #Formatting the date
    current_time = current_time.strftime('%H:%M:%S')
    current_time_split: list = current_time.split(':')

    day_hours: str = ('24:00')
    day_hours_split: list = day_hours.split(':')
    #Converting the hours in a 24 hour day to seconds
    day_hours_seconds = int(day_hours_split[0])*60*60

    current_time_split: list = current_time.split(':')
    #Converting the hours of the current time to seconds
    current_time_hours_seconds = int(current_time_split[0])*60*60
    #Converting the minutes of the current time to seconds
    current_time_minutes_seconds = int(current_time_split[1])*60
    current_time_total_seconds: int = current_time_hours_seconds + current_time_minutes_seconds + int(current_time_split[2])

    scheduled_time_split: list = update_interval.split(':')
    try:
        #Converting the hours of the current time to seconds
        scheduled_time_hours_seconds = int(scheduled_time_split[0])*60*60
    except ValueError:
        logger.exception('Invalid or Empty Scheduled Time')
        #In the case of an error, the update will be set 24 hours from now
        scheduled_total_seconds = 86400
    else:
        #Converting the minutes of the current time to seconds
        scheduled_time_minutes_seconds = int(scheduled_time_split[1])*60
        scheduled_time_total_seconds: int = scheduled_time_hours_seconds + scheduled_time_minutes_seconds

        #If the update has been scheduled for the following day
        if current_time_split > scheduled_time_split:
            seconds_left_in_day: int = day_hours_seconds - current_time_total_seconds
            scheduled_total_seconds: int =(seconds_left_in_day + scheduled_time_total_seconds)
        elif current_time == scheduled_time_split:
            scheduled_total_seconds = day_hours_seconds
        else:
            #Only other option is current_time < scheduled_time
            scheduled_total_seconds = scheduled_time_total_seconds - current_time_total_seconds

    return scheduled_total_seconds
