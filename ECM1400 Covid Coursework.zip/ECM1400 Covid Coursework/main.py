"""
Creates a dashboard with covid data and news articles from the imported modules being
displayed via a html template. The user is able to enable to manually trigger news and
covid data updates, schedule and cancel future updates and remove news articles.

"""
import time
import sched

import logging

from flask import Flask
from flask import render_template

import flask

import covid_data_handler
import covid_news_handling

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s')
file_handler = logging.FileHandler('main.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

sched_updates: list = covid_data_handler.data_sched_updates
deleted_articles: list = []
deleted_updates: list = []
ARTICLE_INDEX = 5

app = Flask(__name__)

@app.route('/')
@app.route('/index')

def main():

    """
    Creates a user interface which will display national and local covid data as well as
    news articles, which are called from the other modules, 'covid_data_handler' and
    'covid_news_handling' respectfully. Users are able to schedule updates to both the
    covid data and the news articles that are shown by using the 'schedule data updates'
    section at the bottom of the user interface, these updates being added to the list
    'sched_updates' which is rendered and displayed onto the dashboard.
    A user can further interact with the dashboard by deleting updates and news articles
    from the dashboard, these deleted elements are then added to their own respective lists;
    'deleted_articles' and 'deleted_updates' which are then checked upon a page refresh
    to ensure that they're not displayed on the interface again, and thus deleted.

    Returns:
        render_template : A user interface with parameters to input certain infomation
        to the webpage
    """
    global ARTICLE_INDEX

    national_location, national_last_7_days_cases, national_cumulative_deaths, hospital_cases, local_location, local_last_7_days_cases = covid_data_handler.covid_API_request()
    covid_news: list = covid_news_handling.news_API_request()

    covid_data_handler.schedule_covid_updates(update_interval = flask.request.args.get('update'),update_name = flask.request.args.get('two'))
    covid_news_handling.update_news(update_interval = flask.request.args.get('update'),update_name = flask.request.args.get('two'))
    #Mapping the exit button on the dashboard wigits from the HTML to python variables to maniuplate
    update_deleted = flask.request.args.get('update_item')
    article_deleted = flask.request.args.get('notif')
    displayed_news: list = []

    #5 articles will always be displayed for formatting purposes
    for i in range (0,5):
        displayed_news.append(covid_news[i])

    #When a user has deleted an article it will be replaced with a new article
    if article_deleted:
        deleted_articles.append(article_deleted)
        log_deleted_article = article_deleted, 'Has been deleted'
        logger.info(log_deleted_article)

    for article in displayed_news:
        if article.get('title') in deleted_articles:
            displayed_news.remove(article)
            displayed_news.append(covid_news[ARTICLE_INDEX])
            ARTICLE_INDEX = ARTICLE_INDEX + 1
            if ARTICLE_INDEX >= len(covid_news):
                ARTICLE_INDEX = 5
            else:
                ARTICLE_INDEX = ARTICLE_INDEX + 1

    #When an update is deleted it will be removed from the dashboard
    if update_deleted:
        deleted_updates.append(update_deleted)

    for update in sched_updates:
        if update.get('title') in deleted_updates:
            log_update_info = update.get('content')
            log_deleted_update = log_update_info, 'Has been deleted'
            logger.info(log_deleted_update)
            sched_updates.remove(update)

    return render_template('index.html',
                           title = 'Daily Update', location = local_location,
                           local_7day_infections = local_last_7_days_cases,
                           nation_location = national_location,
                           national_7day_infections = national_last_7_days_cases,
                           hospital_cases = ("Hopsital Cases: " + str(hospital_cases)),
                           deaths_total = ("Death Total: " + str(national_cumulative_deaths)),
                           news_articles = displayed_news,
                           updates = sched_updates
                           )

if __name__ == '__main__':
    global SCHEDULER_OBJECT
    SCHEDULER_OBJECT = sched.scheduler(time.time, time.sleep)
    logger.info('The Dashboard has been launched')
    app.run()
