"""
Handles all the Covid data handling functionality
"""

import time
import sched
import datetime

import logging
from configparser import ConfigParser

import flask

from uk_covid19 import Cov19API

#Setting up a logging file for this module
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s:%(asctime)s:%(name)s:%(funcName)s:%(message)s')
file_handler = logging.FileHandler('covid_data_handler.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

#Linking this module to the config file
FILE = 'config.json'
config = ConfigParser()
config.read(FILE)

data_sched_updates: list = []
SCHEDULEROBJECT = sched.scheduler(time.time, time.sleep)

def parse_csv_data(csv_filename: str) -> list:

    """
    Splits the excel document 'nation_2021-10-28.csv' by each row and will add
    each row to the list 'lines', returning the list

    Args:
        csv_filename : The file in which its elements will be split

    Returns:
        lines: A list containing each row in the file as individual elements
    """

    with open(csv_filename, 'r') as file:

        lines: list = []

        for line in file:
            individual_line: str = line.strip()
            lines.append(individual_line)

    return lines

def process_covid_csv_data(covid_csv_data: list) -> int:
    """
    Takes the list 'lines' defined in the function 'parse_csv_data' and will
    return the following variables; the number of cases in the last 7 days, the
    current number of hospital cases and the cumulative number of deaths

    Args:
        covid_csv_data: A list containing each row in the file as individual
        elements - the contents returned from the funciton 'parse_csv_data'

    Returns:
        last7days_cases: The sum of cases in the last 7 days ignoring the most recent entry
        current_hospital_cases: The current amount of hospital cases
        total_deaths: The amount of total deaths
    """
    last_7_days_cases: int = 0
    current_hospital_cases: int = 0
    total_deaths: int = 0

    date_counter: int = 0

    for i in range (1, len(covid_csv_data)):

        individual_line: list = covid_csv_data[i].split(',')

        #Start from index 3  ignoring the first entry as the data is incomplete for that day
        if i > 2:
            if date_counter < 7:
                last_7_days_cases = last_7_days_cases + int(individual_line[6])
            date_counter = date_counter + 1
        #Ensuring that cell is not empty and and the most recent value is stored
        if len(individual_line[5]) > 0 and current_hospital_cases == 0:
            current_hospital_cases = individual_line[5]
        if len(individual_line[4]) > 0 and total_deaths == 0:
            total_deaths = individual_line[4]
    return (last_7_days_cases, current_hospital_cases, total_deaths)


def covid_API_request(location = 'Exeter', location_type = 'ltla') -> int:
    """
    Will return up to date covid data as a dictionary for the specified location
    and location_type, England & nation and Exeter & ltla. The data that will be
    returned are the ones defined within their respective strcutres

    Returns:
        national_location, local_location : (str) The location of the data we're
        accessing national_last_7_days_cases,local_last_7_days_cases : (int) The
        sum of cases in the last 7 days national_cumulative_deaths : The amount
        of total deaths, the cumulative amount hospital_cases : The current
        amount of hospital cases
    """
    logger.info('Module Called')
    location = (config['location']['local_location'])

    area_type_filter = 'areaType='+location_type
    area_name_filter = 'areaName='+location

    #Specifying the location in which the data is coming from
    england_only: list = [
    'areaType=nation',
    'areaName=England'
    ]

    #The data we want returned from the API
    england_structure: dict= {
        "date": "date",
        "areaName": "areaName",
        "newCasesByPublishDate": "newCasesByPublishDate",
        "cumDeaths28DaysByDeathDate": "cumDeaths28DaysByDeathDate",
        "hospitalCases": "hospitalCases"
        }

    england_api = Cov19API(filters = england_only, structure = england_structure)
    england_data: dict = england_api.get_json()

    national_covid_data: list = (england_data['data'])

    national_last_7_days_cases: int = 0
    national_cumulative_deaths: int = 0
    hospital_cases: int = 0

    national_date_counter: int = 0

    for i in range (len(national_covid_data)):

        individual_element: dict = (national_covid_data[i])
        national_location: str = individual_element['areaName']

        if national_date_counter < 7:
            #Ignoring the 'noneType' data entries
            if isinstance(individual_element['newCasesByPublishDate'], int):
                national_last_7_days_cases = national_last_7_days_cases + (individual_element['newCasesByPublishDate'])
                national_date_counter = national_date_counter + 1
        if (isinstance(individual_element['cumDeaths28DaysByDeathDate'], int)) and national_cumulative_deaths == 0:
            national_cumulative_deaths = national_cumulative_deaths + (individual_element['cumDeaths28DaysByDeathDate'])

        if (isinstance(individual_element['hospitalCases'], int)) and hospital_cases == 0:
            hospital_cases = hospital_cases + (individual_element['hospitalCases'])

    exeter_only: list = [
        area_type_filter,
        area_name_filter
        ]

    exeter_structure: dict = {
        "date": "date",
        "areaName": "areaName",
        "newCasesByPublishDate": "newCasesByPublishDate",
        }

    exeter_api = Cov19API(filters = exeter_only, structure = exeter_structure)
    exeter_data: dict = exeter_api.get_json()

    local_covid_data: list = (exeter_data['data'])

    local_last_7_days_cases: int = 0
    local_date_counter: int = 0

    for i in range (2, len(local_covid_data)):

        individual_element: dict = (local_covid_data[i])
        local_location: str = individual_element['areaName']

        if local_date_counter < 7:
            if isinstance(individual_element['newCasesByPublishDate'], int):
                local_last_7_days_cases = local_last_7_days_cases + (individual_element['newCasesByPublishDate'])
                local_date_counter = local_date_counter + 1

    return(national_location, national_last_7_days_cases, national_cumulative_deaths, hospital_cases, local_location, local_last_7_days_cases)


def schedule_covid_updates(update_interval: str, update_name: str) -> None:

    """
    Initially it will check to see which checkbox has been ticked on the user interface, a
    user will provide a an update interval and an update name on the user interface which will
    then be used to schedule and name an update to the covid data the given time interval.
    These updates are also added to the list 'data_sched_updates' so that it can be displayed
    onto the user interface

    Args:
        update_interval : The input from the time field on the user interface, this is the time
        in which the user has specified an update for the covid data to take place
        update_name : The input from the field 'update label' on the website, this is what
        will be displayed as the title of the update on the scheduled update widgits.
    """
    #Mapping the checkboxes and exit buttons on the HTML to python variables to manipulate
    covid_data_ticked = flask.request.args.get('covid-data')
    repeat_update_ticked = flask.request.args.get('repeat')

    if covid_data_ticked:
        scheduled_total_seconds: int = time_conversion(update_interval)

        update: dict = {'title':update_name, 'content':'Covid Data Update Scheduled for ' + update_interval}
        logger.info(update)
        data_sched_updates.append(update)

        #Will recall the covid_API_request function essencially 'updating' the data structure
        SCHEDULEROBJECT.enter(scheduled_total_seconds, 1, covid_API_request)

    if repeat_update_ticked:

        scheduled_total_seconds = time_conversion(update_interval)

        update = {'title':update_name, 'content':'Repeated Update Scheduled for ' + update_interval}
        logger.info(update)
        data_sched_updates.append(update)

def time_conversion(update_interval: str) -> int:

    """
    Converts the current time and a scheduled time provided into seconds finding the difference
    between the two, to know what time to schedule an update for.

    Args:
        update_interval : The input from the time field on the user interface, this is the time
        in which the user has specified an upodate to take place

    Returns:
        scheduled_total_seconds : The difference between the current time and scheduled time
        in seconds
    """
    current_time: int = datetime.datetime.now()
    #Formatting the date
    current_time = current_time.strftime('%H:%M:%S')
    current_time_split: list = current_time.split(':')

    day_hours: str = ('24:00')
    day_hours_split: list = day_hours.split(':')
    #Converting the hours in a 24 hour day to seconds
    day_hours_seconds = int(day_hours_split[0])*60*60

    current_time_split: list = current_time.split(':')
    #Converting the hours of the current time to seconds
    current_time_hours_seconds = int(current_time_split[0])*60*60
    #Converting the minutes of the current time to seconds
    current_time_minutes_seconds = int(current_time_split[1])*60
    current_time_total_seconds: int = current_time_hours_seconds + current_time_minutes_seconds + int(current_time_split[2])

    scheduled_time_split: list = update_interval.split(':')
    try:
        #Converting the hours of the current time to seconds
        scheduled_time_hours_seconds = int(scheduled_time_split[0])*60*60
    except ValueError:
        logger.exception('Invalid or Empty Scheduled Time')
        #In the case of an error, the update will be set 24 hours from now
        scheduled_total_seconds = 86400
    else:
        #Converting the minutes of the current time to seconds
        scheduled_time_minutes_seconds = int(scheduled_time_split[1])*60
        scheduled_time_total_seconds: int = scheduled_time_hours_seconds + scheduled_time_minutes_seconds

        #If the update has been scheduled for the following day
        if current_time_split > scheduled_time_split:
            seconds_left_in_day: int = day_hours_seconds - current_time_total_seconds
            scheduled_total_seconds: int =(seconds_left_in_day + scheduled_time_total_seconds)
        elif current_time == scheduled_time_split:
            scheduled_total_seconds = day_hours_seconds
        else:
            #Only other option is current_time < scheduled_time
            scheduled_total_seconds = scheduled_time_total_seconds - current_time_total_seconds

    return scheduled_total_seconds
